/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso_pck;

import static pso_pck.AllocateThread.allocatethread;
import static pso_pck.Start.end;
import static pso_pck.QueueAddInput.queueaddinput;
import static pso_pck.Start.maxmessages;
import static pso_pck.Start.messinbound;
import static pso_pck.Start.messproc;
import static pso_pck.Start.messrem;
import static pso_pck.Start.preemptask;
import static pso_pck.Start.queues;
import static pso_pck.Start.start;
import static pso_pck.Start.throughput;

/**
 *
 * @author DANI 
 */
public class Fifo {

    public static void fifo() {

        int totsize;
        
//        Adiciona o tempo de chegada da primeira messagen
        start = System.currentTimeMillis();
        
        throughput = 0;
        messproc = 0;
        messrem = 0;
        messinbound = 0;
        start = 0;
        end = 0;
        
        //Adiciona um numero de "numinstance" tarefas 1 para queues[1] (queue[1])
        queueaddinput();

        while (!queues[0].isEmpty()) {

            allocatethread(queues[0], maxmessages);

        }


        messrem = queues[0].size();;
        if (messproc > 0) {
            throughput = (messproc / (end - start));

            System.out.println("preempt " + preemptask + " throughput " + throughput);
            System.out.println("Total inbound messages = " + messinbound);
            System.out.println("Total processed = " + messproc);
            System.out.println("Total remaining = " + messrem);
            System.out.println("throughput(messages/ms) = " + throughput);

        }
    }
}
