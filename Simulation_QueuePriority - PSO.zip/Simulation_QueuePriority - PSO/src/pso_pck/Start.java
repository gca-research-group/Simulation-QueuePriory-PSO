package pso_pck;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import static pso_pck.GravarArquivo.GravarArquivo;
import static pso_pck.ProfileIntegrationProcess.NumTasks;
import static pso_pck.PSO.iterate;
import static pso_pck.PSO.psoInit;
import static pso_pck.qPrior.qPrior;
import static pso_pck.Fifo.fifo;

/**
 *
 * @author DANI encontra o melhor valor para a preempç]ao na heuistica qPriorPSO
 * através do PSO
 */
public class Start {

    public static int numSimulation = 25;
    public static int numtask = NumTasks;
    public static int maxmessages = 5000000;
    public static double numinstance = 1000;
    public static double numinputtask = 1000;
    public static int numparticles = 20;
    public static double preemptask = 50000;
    public static Random gerador = new Random();
    public static double start;
    public static double end;
    public static double throughput = 0;
    public static int messproc = 0;
    public static int messrem = 0;
    public static int messinbound = 0;
    public static double bpreempt;
    public static double bthroughput;
    public static double duration = 0;
    public static int PSO = 0;

    public static String policy = "FIFO";// usa Fifo
//    public static String policy = "qPrior";//usa prioridade para as ultimas filas

    public static final Queue<Integer>[] queues = new Queue[numtask + 1];

    public static StringBuilder simulationText = new StringBuilder();

    /**
     *
     * @param args
     */
    public static void main(String args[]) {

        String simulationFile = "Simulation.txt";

        double ini = System.currentTimeMillis();

        if (PSO == 1) {

            PSO.State state = psoInit(
                    new double[]{25000, 50000},
                    new double[]{50000, 75000},
                    new PSO.Parameters(1, 1, 1), numparticles);

            state = iterate(qPriorPSO::qPriorPSO, 100, state);

            duration = System.currentTimeMillis() - ini;

            state.report("qPriorPSO");
            System.out.printf("f(25000, 75000) : %.15f\n", qPriorPSO.qPriorPSO(new double[]{25000, 75000}));
            System.out.println();

            simulationFile = "SimulationPSO.txt";

            simulationText.append(numparticles).append(" ").append(bpreempt).append(" ").append(bthroughput).append(" ").append(duration).append("\n");
            GravarArquivo(simulationFile, simulationText.toString());

        } else {

            for (int k = 1; k <= numSimulation; k++) {

                switch (policy) {
                    case "FIFO": {

                        queues[0] = new LinkedList<>();

                        simulationFile = "SimulationFIFO"+maxmessages+".txt";
                        fifo();
                        break;
                    }
                    case "qPrior": {

                        for (int i = 1; i <= numtask; i++) {

                            queues[i] = new LinkedList<>();
                        }

                        simulationFile = "SimulationqPrior" + maxmessages + ".txt";
                        qPrior();
                        break;
                    }
                }

                simulationText.append(preemptask).append(" ").append(messinbound).append(" ").append(messproc).append(" ").append(messrem).append(" ").append(throughput).append("\n");
                GravarArquivo(simulationFile, simulationText.toString());
            }
        }
    }
}
