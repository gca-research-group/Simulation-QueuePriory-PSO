package pso_pck;

import java.util.concurrent.ThreadFactory;

/**
 *
 * @author DANI
 * classe thread
 */

public class MyThreadFactory implements ThreadFactory {

    //public static int count = 1;

    /**
     *
     * @param r
     * @return
     */
        
    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r);
        return t;              
    }
    
        
}
