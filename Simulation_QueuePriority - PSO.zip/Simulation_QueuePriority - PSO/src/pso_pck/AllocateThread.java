package pso_pck;

import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import static pso_pck.NextTask.nexttask;
import static pso_pck.ProfileIntegrationProcess.LastTask;
import static pso_pck.QueueAddInput.queueaddinput;
import static pso_pck.Start.end;
import static pso_pck.Start.maxmessages;
import static pso_pck.Start.messinbound;
import static pso_pck.Start.messproc;
import static pso_pck.Start.preemptask;

/**
 *
 * @author DANI Executa tarefa da fila e gera a prox tarefa
 */
public class AllocateThread {

    /**
     *
     */
    public static int ptask;

    /**
     *
     * @param q
     * @param preemp
     */
    public static void allocatethread(Queue<Integer> q, int preemp) {

        ExecutorService executor = Executors.newCachedThreadPool(new MyThreadFactory());

        int task;
        int lasttask = 0;
        double count = 100;

        for (int i = 1; i <= preemp; i++) {

            if (q.peek() != null) {
                task = q.peek();
                ptask = task;//enviada para Operation

                Runnable runnable1 = () -> {
                    executor.submit(new Operation());
                };

                for (int j = 0; j < LastTask.length; j++) {//ate a ultima tarefa do processo de integracao

                    if (task == LastTask[j]) {
                        lasttask = 1;
                    }
                }
                if (lasttask == 0 && task != 0) {  //se nao for a ultima tarefa, gera indicação da prox tarefa
                    nexttask(task);
                } else {
                    //Adiciona o tempo de saida da ultima messagem
                    end = System.currentTimeMillis();

                    messproc = messproc + 1;  //mensagens processaadas

                }

                q.remove();

                executor.shutdownNow();
            }
            
            //Adiciona novas messagem
            if (maxmessages > messinbound) {
                if (i == count) {
                    queueaddinput();
                    count = count + 100;
                }
            }
        }
    }
}
