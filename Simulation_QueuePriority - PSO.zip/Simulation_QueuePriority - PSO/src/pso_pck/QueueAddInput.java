package pso_pck;

import static pso_pck.Start.numinputtask;
import static pso_pck.Start.messinbound;
import static pso_pck.Start.maxmessages;
import static pso_pck.Start.messproc;
import static pso_pck.Start.queues;
import static pso_pck.Start.policy;


/**
 *
 * @author DANI simula a entrada de novas tarefas
 */
public class QueueAddInput {

    /**
     *
     */
    public static void queueaddinput() {
        if (maxmessages - messproc < numinputtask) {
            numinputtask = maxmessages - messproc;
        }
        for (int i = 0; i < numinputtask; i++) {

            //Adiciona "numinstance" tarefas 1 para queues[0] 
            if ("FIFO".equals(policy)) {
                queues[0].add(1);
            } //Adiciona "numinstance" tarefas 1 para queues[1] 
            else {
                queues[1].add(1);
            }
                      
            messinbound = messinbound +1;
        }
    }
}
