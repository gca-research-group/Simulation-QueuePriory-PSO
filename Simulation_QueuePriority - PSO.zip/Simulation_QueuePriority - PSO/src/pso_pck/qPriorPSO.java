/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pso_pck;

import java.util.LinkedList;
import static pso_pck.AllocateThread.allocatethread;
import static pso_pck.Start.end;
import static pso_pck.Start.messinbound;
import static pso_pck.Start.numtask;
import static pso_pck.Start.preemptask;
import static pso_pck.Start.messrem;
import static pso_pck.QueueAddInput.queueaddinput;
import static pso_pck.Start.maxmessages;
import static pso_pck.Start.messproc;
import static pso_pck.Start.numtask;
import static pso_pck.Start.policy;
import static pso_pck.Start.queues;
import static pso_pck.Start.start;
import static pso_pck.Start.throughput;

/**
 *
 * @author DANI
 */
public class qPriorPSO {

    public static double qPriorPSO(double x[]) {
        int bestpreemp = (int) x[1];
        int totsize = 1;//tamanho total das filas
        boolean NoEmpty = true;
        int qprior = numtask;
        int preemp = bestpreemp;

        throughput = 0;
        messproc = 0;
        messrem = 0;
        messinbound = 0;
        start = 0;
        end = 0;

        policy = "qPrior";

        for (int i = 1; i <= numtask; i++) {

            queues[i] = new LinkedList<>();
        }

        //Adiciona o tempo de chegada da primeira messagen
        start = System.currentTimeMillis();

        //Adiciona um numero de "numinstance" tarefas 1 para queues[1] (queue[1])
        queueaddinput();

        while (NoEmpty) {

            preemp = (int) bestpreemp;

            for (int i = numtask; i >= 1; i--) {
                if (!queues[i].isEmpty()) {
                    qprior = i;
                    i = 0;
                }
            }

            if (preemp == 0 || queues[qprior].size() < preemp) {
                preemp = queues[qprior].size();
            } else {
                preemp = (int) preemptask;
            }

            allocatethread(queues[qprior], (int) preemp);

            for (int j = 1; j <= numtask; j++) {
                if (!queues[j].isEmpty()) {
                    j = numtask + 1;
                    NoEmpty = true;
                } else {
                    NoEmpty = false;
                }
            }
        }

        totsize = 0;

        for (int j = 1; j <= numtask; j++) {
            totsize = totsize + queues[j].size();
        }

        messrem = totsize;
        if (messproc > 0) {
            throughput = (messproc / (end - start));
        }
//                System.out.println("preempt " + bestpreemp + " throughput " + throughput);
        return 1 / throughput;
    }

}
