package pso_pck;

import static pso_pck.AllocateThread.allocatethread;
import static pso_pck.Start.end;
import static pso_pck.Start.numtask;
import static pso_pck.QueueAddInput.queueaddinput;
import static pso_pck.Start.messinbound;
import static pso_pck.Start.messproc;
import static pso_pck.Start.messrem;
import static pso_pck.Start.preemptask;
import static pso_pck.Start.queues;
import static pso_pck.Start.start;
import static pso_pck.Start.throughput;

/**
 *
 * @author gca
 */
public class qPrior {

    public static double qPrior( ) {
      
        int totsize = 1;//tamanho total das filas
        boolean NoEmpty = true;
        int qprior = numtask;
        int preemp;

        throughput = 0;
        messproc = 0;
        messrem = 0;
        messinbound = 0;
        start = 0;
        end = 0;

        //Adiciona o tempo de chegada da primeira messagen
        start = System.currentTimeMillis();
        
        //Adiciona um numero de "numinstance" tarefas 1 para queues[1] (queue[1])
        queueaddinput();

        while (NoEmpty) {
            
            preemp = (int) preemptask;

            for (int i = numtask; i >= 1; i--) {
                if (!queues[i].isEmpty()) {
                    qprior = i;
                    i = 0;
                }
            }

            if (preemp == 0 || queues[qprior].size() < preemp) {
                preemp = queues[qprior].size();
            } else {
                preemp = (int) preemptask;
            }

            allocatethread(queues[qprior], (int) preemp);

            for (int j = 1; j <= numtask; j++) {
                if (!queues[j].isEmpty()) {
                    j = numtask + 1;
                    NoEmpty = true;
                }
                else {    
                    NoEmpty = false;
                }
            }
        }
        
        totsize = 0;
        
        for (int j = 1; j <= numtask; j++) {
            totsize = totsize + queues[j].size();
        }

        messrem = totsize;
        if (messproc > 0) {
            throughput = (messproc / (end - start));
        
            System.out.println("preempt " + preemptask + " throughput " + throughput);
            System.out.println("Total inbound messages = " + messinbound);
            System.out.println("Total processed = " + messproc);
            System.out.println("Total remaining = " + messrem);
            System.out.println("throughput(messages/ms) = " + throughput);

        }
        return throughput;
    }
}
